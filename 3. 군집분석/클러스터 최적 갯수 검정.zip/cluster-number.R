## ----setup, include=FALSE, cache=FALSE-----------------------------------
library(knitr)
library(splines)
library(ggplot2)
library(lattice)
library("MVA")
library(xlsx)
options(formatR.arrow=TRUE,width=90,digits = 4)
opts_chunk$set(fig.path='figure/graphics-', cache.path='cache/graphics-', fig.align='center', fig.width=5, fig.height=5, fig.show='hold')

## ----exampledata---------------------------------------------------------
setwd('C:/Users/ce401Prof/rbigdata/')
data1 <- read.csv("C:/Users/ce401Prof/rbigdata/francise.csv",header=T)
## ----manycluster---------------------------------------------------------
K <- 1:10
clusList <- list()
for ( k in K) {
  clusList[[k]] <- kmeans(data1[c(23:27,16)],center=k)
}
# this is another way
# clusList <- lapply(K, function(x,d) { kmeans(d,center=x) },d=data1 ) 
ssT <- getElement(clusList[[1]],"totss")  # 총제곱합
ssT

## ----ssb, fig.height=4,fig.width=4---------------------------------------
ssB <- sapply(clusList, function(x){getElement(x,"betweenss")} ) # 군집간의 제곱합
ssB
plot(K, ssB, xlab="number of clusters", ylab="between group sum of square")
lines(K, ssB)

## ----ssw, fig.height=4,fig.width=4---------------------------------------
ssW <- sapply(clusList,function(x){getElement(x,"tot.withinss")}) # 군집내 제곱합을 더한값
ssW
plot(K, ssW, xlab="number of clusters", ylab="within group sum of sqaure")
lines(K, ssW)


## ------------------------------------------------------------------------
K <- 1:30
clusList <- list()
clusList <- lapply(K, function(x,d) { kmeans(d,center=x) },d=data1[c(23:27,16)] ) 
ssB <- sapply(clusList, function(x){getElement(x,"betweenss")} ) # 군집간의 제곱합
ssW <- sapply(clusList,function(x){getElement(x,"tot.withinss")}) # 군집내 제곱합을 더한값
n <- dim(data1[c(23:27,16)])[1]
chindex <- (ssB/(K-1))/(ssW/(n-K)) 
chindex
plot(K, chindex, xlab="number of clusters", ylab="CH index", main="Francise data: CH index")
lines(K, chindex)

## ------------------------------------------------------------------------
KK <- 2:10
silval <- KK
for ( k in KK) {
  ss <- silhouette(clusList[[k]]$cluster, dist(data1[c(23:27,16)]))
  silval[k] <- mean( ss[,3])
}
silval
# NOTICE: eleminate the first value of silhouette value
plot(KK, silval[-1], xlab="number of clusters", ylab="silhouette value",main="Francise data:Average silhouette")
lines(KK, silval[-1])

## ------------------------------------------------------------------------
gap_stat <- clusGap(data1[c(23:27,16)], FUNcluster = kmeans, nstart=25, K.max = 10, B = 100)
print(gap_stat, method = "firstmax")
plot(gap_stat, frame = FALSE, xlab = "Number of clusters k",main="Francise data: GAP statistics")

setwd('C:/Users/ce401Prof/rbigdata/')
data = read.csv('francise_cluter.csv')

library("GGally")
ggpairs(data,2:7)
